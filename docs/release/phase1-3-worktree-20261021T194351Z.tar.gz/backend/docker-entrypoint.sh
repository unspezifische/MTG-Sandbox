#!/bin/sh
set -eu

# Gunicorn imports run:app but does not execute run.py's __main__ block.
# Preserve the Docker development stack's idempotent schema initialization
# before replacing this process with the production server.
python -c 'from run import initialize_database; initialize_database()'

exec "$@"
