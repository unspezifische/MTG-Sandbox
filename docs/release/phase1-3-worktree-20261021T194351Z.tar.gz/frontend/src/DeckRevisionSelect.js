import React from "react";

export default function DeckRevisionSelect({ deck, value, onChange, label = "Deck version" }) {
  if (!deck?.sourcePreconId) return null;
  return (
    <label className="lobby-field">
      <span>{label}</span>
      <select className="modal-input" value={value} onChange={(event) => onChange(event.target.value)}>
        <option value="current">Play My Version</option>
        <option value="stock">Play Original Precon</option>
      </select>
    </label>
  );
}
