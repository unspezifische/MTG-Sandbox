import React, { useEffect, useState } from "react";

const isMtgSubpath = window.location.pathname.startsWith("/mtg");
const API_BASE = isMtgSubpath ? "/mtg/api" : "/api";

function displayDate(value) {
  if (!value) return "Release date unavailable";
  const date = new Date(`${value}T00:00:00`);
  return Number.isNaN(date.getTime())
    ? value
    : new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "numeric" }).format(date);
}

export default function PreconsPage({ onOpenDeck }) {
  const [query, setQuery] = useState("");
  const [submittedQuery, setSubmittedQuery] = useState("");
  const [precons, setPrecons] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [savingId, setSavingId] = useState(null);

  useEffect(() => {
    const controller = new AbortController();
    async function loadPrecons() {
      setLoading(true);
      setError("");
      try {
        const params = new URLSearchParams({ limit: "100" });
        if (submittedQuery) params.set("q", submittedQuery);
        const response = await fetch(`${API_BASE}/precons?${params}`, { signal: controller.signal });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload?.error || "Could not load preconstructed decks.");
        setPrecons(Array.isArray(payload.precons) ? payload.precons : []);
        setTotal(Number(payload.total || 0));
      } catch (loadError) {
        if (loadError.name !== "AbortError") setError(loadError.message);
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }
    loadPrecons();
    return () => controller.abort();
  }, [submittedQuery]);

  async function savePrecon(precon) {
    setSavingId(precon.id);
    setError("");
    try {
      const response = await fetch(`${API_BASE}/precons/${precon.id}/save`, { method: "POST" });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload?.error || "Could not add this precon to your decks.");
      onOpenDeck(payload.id);
    } catch (saveError) {
      setError(saveError.message);
      setSavingId(null);
    }
  }

  return (
    <div className="decks-page precons-page">
      <section className="decks-hero precons-hero">
        <div>
          <div className="eyebrow">Official deck catalog</div>
          <h1>Browse precons</h1>
          <p>Find a ready-to-play deck, add it to your library, and make it your own.</p>
        </div>
        <form
          className="precon-search"
          role="search"
          onSubmit={(event) => {
            event.preventDefault();
            setSubmittedQuery(query.trim());
          }}
        >
          <label className="sr-only" htmlFor="precon-search">Search preconstructed decks</label>
          <input
            id="precon-search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search by deck or set…"
          />
          <button type="submit" className="button-primary">Search</button>
        </form>
      </section>

      <section className="decks-panel">
        <div className="decks-panel-toolbar">
          <div>
            <h2>Preconstructed decks</h2>
            <span>{total} {total === 1 ? "deck" : "decks"}</span>
          </div>
          {submittedQuery && (
            <button
              type="button"
              className="button-secondary"
              onClick={() => {
                setQuery("");
                setSubmittedQuery("");
              }}
            >
              Clear search
            </button>
          )}
        </div>

        {loading && <div className="deck-empty-state">Loading the precon catalog…</div>}
        {error && <div className="error-box">{error}</div>}
        {!loading && !error && precons.length === 0 && (
          <div className="deck-empty-state">
            <div className="empty-icon">◇</div>
            <h3>{submittedQuery ? "No precons match that search" : "No precons are available yet"}</h3>
            <p>{submittedQuery ? "Try a deck name or set code." : "The official catalog needs to be synced before decks appear here."}</p>
          </div>
        )}

        {!loading && precons.length > 0 && (
          <div className="precon-grid">
            {precons.map((precon) => (
              <article className="precon-card" key={precon.id}>
                <div className="precon-card-heading">
                  <span className="format-pill">{precon.format || "precon"}</span>
                  <span>{precon.setCode || "Set unknown"}</span>
                </div>
                <h3>{precon.name}</h3>
                <p>{displayDate(precon.releaseDate)}</p>
                <div className="precon-card-footer">
                  <span className={precon.gameplayAvailable ? "catalog-ready" : "catalog-unavailable"}>
                    {precon.gameplayAvailable ? "Ready to play" : "Decklist unavailable"}
                  </span>
                  <button
                    type="button"
                    className="button-primary"
                    disabled={!precon.gameplayAvailable || savingId === precon.id}
                    onClick={() => savePrecon(precon)}
                  >
                    {savingId === precon.id ? "Adding…" : "Add to Your Decks"}
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
